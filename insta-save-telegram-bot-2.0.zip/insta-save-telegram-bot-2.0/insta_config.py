# USERNAME and PASSWORD for Instagram account
USERNAME = ""
PASSWORD = ""